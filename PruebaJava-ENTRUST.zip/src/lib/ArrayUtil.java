package lib;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * Clase de metodos utilitarios que involucran operaciones sobre los arreglos,
 * las operaciones de estos metodos pueden no tener objetivos relacionados pero
 * siempre involucran arreglos como datos de entrada a manejar.
 * 
 * @author Ing. Manuel Lara (lararojas.mr@gmail.com)
 * @date 24/08/2016
 */
public class ArrayUtil {

    /**
     * Metodo que a partir de un arreglo unidimensional con una serie de valores
     * enteros con posibles repetidos, regresa un arreglo unidimensional con
     * valores no repetidos que indican de manera descendente, los valores con
     * mas probabilidades de salir si se pusiera a escojer a un usuario al azar.
     * 
     * Es decir si tenemos, por ejemplo:
     * 
     *  [1,2,6,8,1,1,2,6] como arreglo origen.
     * 
     * al pasar nuestro arreglo a la funcion, este devolveria:
     * 
     *  [1,2,6,8]
     * 
     * Nota: Los valores con probabilidades repetidas se mantienen juntos, es
     * decir, se agrupan en orden en el que son procesados.
     * 
     * @param origen vector oigen de los datos a procesar
     * @return vector de numeros en orden descendente tomando como critero la 
     * probabilidad de aparecer al ser seleccionado algun item del vector original.
     */
    public Integer[] getProbabilities(int[] origen) {

        //validamos que el vector cumpla con los requisios minimos
        if (origen == null) {
            //si no se cumplen se emite un mensaje de error indicando formato incorrecto
            throw new NumberFormatException();
        }
        /**
         * la logica del algoritmo comienza aqui, instanciamos un HashMap, 
         * el cual es mas eficiente en general y nos permite agregar un par
         * <key, value> donde en uno se guardara el numero y en el otro la
         * cantidad de veces que se repitio.
         * 
         * Mediante esto, no tendremos que hacer sino un solo recorrido por el 
         * arreglo, lo cual nos favorece en tiempo de ejecucion y una 
         * complejidad O(h).
         * 
         * Luego creamos una lista igual, pero en vez de HashMap, creamos una
         * que garantice el ordenamiento (TreeMap), instanciamos una implementacion
         * perzonalizada de un comparador, el cual sera la regla para el 
         * ordenamiento (@see NumberProbabilityComparator). 
         * 
         * Con esta ultima accion, al solo agregar los items del primer map
         * los ordenara, y entonces solo tendremos que recuperar los keys, 
         * que ya estaran ordenados segun la probabilidad, cumpliendo con el 
         * objetivo.
         * 
         */
        //Creamos el mapa donde se agregaran en primera instancia los elementos
        Map<Integer, Integer> numerosContados = new HashMap<>();

        //este for, lo que hace es crear un indice en el mapa y como valor
        //agregar la cantidad de veces que se repite en origen. 
        //Solo hace un recorrido
        for (int index = 0; index < origen.length; index++) {

            if (numerosContados.putIfAbsent(origen[index], 1) != null) {
                //en caso de existir ya, solo se actualiza el numero de ocurrencias
                numerosContados.replace(origen[index], numerosContados.get(origen[index]) + 1);
            }
        }
        //se instancia el comparador que se utilizara para el ordenamiento al insertar
        NumberProbabilityComparator comparador = new NumberProbabilityComparator(numerosContados);
        //creamos nuestra lista ordenada y le asignamos nuestro comparador.
        Map<Integer, Integer> numerosFiltrados = new TreeMap<>(comparador);
        //luego agregamos todos los elementos del HashMap. Se orden automaticamente
        numerosFiltrados.putAll(numerosContados);
        //como no nos interesa sino los elementos ordenados por la probabilidad, 
        //de aparecer, entonces solo necesitamos las claves del MapTree.
        return numerosFiltrados.keySet().toArray(new Integer[0]);
    }
}
